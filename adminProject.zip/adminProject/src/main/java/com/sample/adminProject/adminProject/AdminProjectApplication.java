package com.sample.adminProject.adminProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdminProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdminProjectApplication.class, args);
	}

}
