package com.sample.adminProject.adminProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
